# pips bot — React (Next.js 15) Mini App + Node backend

```
frontend/   Next.js 15 · React 19 · TypeScript · Tailwind  (Nova Store stack: app/, src/config.ts, token-based theme)
backend/    Express + PostgreSQL: Fazer Cards (top-up, gift card, game key), checkout.uz, promo/chegirma, admin API
```

## Deploy (EC2, Docker)
```bash
cp .env.example .env          # BOT_TOKEN, ADMIN_IDS, DB_PASSWORD
# Caddyfile: domen (pips.uz) DNS orqali serverga qaralgan bo'lsin
docker compose up -d --build  # frontend build -> backend/public ga avtomatik ko'chadi
```
BotFather: `/setmenubutton` → `https://pips.uz`. Admin: `https://pips.uz/admin/` (faqat `ADMIN_IDS`, Telegram ichida).
EC2'da nginx bo'lsa, `caddy` servisini o'chirib, nginx'dan `app:3000` ga proxy qiling.

## Birinchi sozlash (Admin → Provayderlar)
Fazer API key + webhook secret, checkout.uz API key, kurs, ustama %, sayt manzili. Saqlagach chiqqan **checkout.uz webhook URL**'ni checkout.uz kassasiga qo'ying; Fazer webhook: `https://pips.uz/webhooks/fazer`. Kalitlar `.env`da emas, DB'da.

## Lokal ishlab chiqish
```bash
cd backend && npm i && DATABASE_URL=... BOT_TOKEN=... ADMIN_IDS=... node server.js   # :3000
cd frontend && npm i && npm run dev                                                   # :8001, /api -> :3000
```
Brauzerda sinash uchun `frontend/.env.local`: `NEXT_PUBLIC_DEV_INIT_DATA=<Telegram initData>`.

## Dizayn
`frontend/tailwind.config.ts` — Nova Next.js nusxasidagi bilan bir xil (token nomlari). Ranglar `frontend/app/globals.css` da (light + `data-theme="dark"`). Nova litsenziyasi: o'z do'koningiz uchun foydalaning, shablon sifatida qayta sotmang.

## Narx tartibi
`tannarx USD × kurs × (1+ustama%)` → eng katta mos chegirma → promo kod; narx tannarxdan past bo'lmaydi.
