'use client';
import { useState } from 'react';
import { useStore } from '@/lib/store';
import { Loading, TopBar } from '@/components/ui';
import { Plain, Products, Providers, RES, Resource } from '@/components/admin';

const TABS: [string, string][] = [
  ['providers', 'Provayderlar'], ['products', 'Mahsulotlar'],
  ...Object.keys(RES).map((k): [string, string] => [k, RES[k].title]),
  ['orders', 'Buyurtmalar'], ['payments', "To'lovlar"],
];

export default function AdminPage() {
  const { me } = useStore();
  const [tab, setTab] = useState('providers');
  if (!me) return <Loading />;
  if (!me.is_admin) return <div className="card text-danger">Ruxsat yo&apos;q</div>;
  return (
    <>
      <TopBar title="Admin" />
      <div className="-mx-3 mb-3 flex gap-2 overflow-x-auto px-3 pb-1">
        {TABS.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`chip whitespace-nowrap ${tab === k ? '!bg-accent !text-accent-contrast' : ''}`}>{l}</button>
        ))}
      </div>
      {tab === 'providers' ? <Providers /> : tab === 'products' ? <Products />
        : tab === 'orders' || tab === 'payments' ? <Plain t={tab} /> : <Resource t={tab} />}
    </>
  );
}
