'use client';
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { api } from '@/lib/api';
import { useAsync } from '@/lib/hooks';
import { kv, som, STATUS } from '@/lib/format';
import { ErrorBox, Loading, TopBar } from '@/components/ui';

type Detail = { order: { id: number; title: string; price_uzs: number | string; status: string }; delivery: unknown };

function Inner() {
  const id = useSearchParams().get('id') || '';
  const { data, error, reload } = useAsync(() => api<Detail>(`/orders/${id}`), [id]);
  return (
    <>
      <TopBar title={`Buyurtma #${id}`} back right={<button className="btn-soft" onClick={reload}>↻</button>} />
      {error ? <ErrorBox msg={error} /> : !data ? <Loading /> : (
        <div className="card">
          <b>{data.order.title}</b>
          <p className="my-2">{som(data.order.price_uzs)}<br /><small className="text-muted">{STATUS[data.order.status] || data.order.status}</small></p>
          {data.delivery != null && (
            <>
              <h3 className="mb-1 font-semibold">Ma&apos;lumot / kodlar</h3>
              <pre className="whitespace-pre-wrap break-all rounded-md bg-surface p-2 text-xs">{kv(data.delivery)}</pre>
            </>
          )}
        </div>
      )}
    </>
  );
}
export default function OrderPage() { return <Suspense fallback={<Loading />}><Inner /></Suspense>; }
