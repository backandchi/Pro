'use client';
import Link from 'next/link';
import { useState } from 'react';
import { api } from '@/lib/api';
import { useAsync } from '@/lib/hooks';
import { openLink } from '@/lib/telegram';
import type { Home } from '@/lib/types';
import { BalanceChip, CatCard, ErrorBox, Loading, TopBar } from '@/components/ui';
import { useStore } from '@/lib/store';
import { config } from '@/config';

export default function HomePage() {
  const { error: authError } = useStore();
  const { data, error } = useAsync(() => api<Home>('/home'), []);
  const [q, setQ] = useState('');
  if (authError || error) return <ErrorBox msg={authError || error} />;
  if (!data) return <Loading />;
  const games = data.topups.filter(c => c.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <TopBar title={config.brand.name} right={<BalanceChip />} />
      {data.banners.length > 0 && (
        <div className="-mx-3 mb-2 flex snap-x snap-mandatory gap-2 overflow-x-auto px-3">
          {data.banners.map(b => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={b.id} src={b.image_url} alt={b.title} onClick={() => b.link && openLink(b.link)}
              className="aspect-[2/1] w-[88%] shrink-0 snap-start rounded-lg bg-surface object-cover" />
          ))}
        </div>
      )}
      <h2 className="mb-2 mt-4 font-semibold">🎮 O&apos;yinlarni to&apos;ldirish</h2>
      <input className="inp" placeholder="O'yin qidirish…" value={q} onChange={e => setQ(e.target.value)} />
      {games.length === 0 && <p className="text-sm text-muted">Kartochkalar topilmadi yoki import qilinmoqda…</p>}
      <div className="grid grid-cols-3 gap-2">{games.map(c => <CatCard key={c.id} sec="topups" c={c} />)}</div>
      <h2 className="mb-2 mt-5 font-semibold">Boshqa bo&apos;limlar</h2>
      <div className="grid grid-cols-2 gap-2">
        {data.sections.map(s => (
          <Link key={s.key} href={`/section/?${new URLSearchParams({ key: s.key, title: s.title })}`}
            className="rounded-lg border border-border bg-card p-4 text-center text-sm font-semibold shadow-card">{s.title}</Link>
        ))}
      </div>
    </>
  );
}
