import './globals.css';
import type { Metadata, Viewport } from 'next';
import Script from 'next/script';
import type { ReactNode } from 'react';
import { StoreProvider } from '@/lib/store';
import { BottomNav } from '@/components/ui';

export const metadata: Metadata = { title: 'pips bot' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', userScalable: false };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body>
        <Script src="https://telegram.org/js/telegram-web-app.js" strategy="beforeInteractive" />
        <StoreProvider>
          <main className="mx-auto max-w-app px-3 pb-28 pt-3">{children}</main>
          <BottomNav />
        </StoreProvider>
      </body>
    </html>
  );
}
