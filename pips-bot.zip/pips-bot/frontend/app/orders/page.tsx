'use client';
import Link from 'next/link';
import { api } from '@/lib/api';
import { useAsync } from '@/lib/hooks';
import { som, STATUS } from '@/lib/format';
import type { OrderRow } from '@/lib/types';
import { ErrorBox, Loading, TopBar } from '@/components/ui';

export default function OrdersPage() {
  const { data, error } = useAsync(() => api<{ items: OrderRow[] }>('/orders'), []);
  return (
    <>
      <TopBar title="Buyurtmalar" />
      {error ? <ErrorBox msg={error} /> : !data ? <Loading /> : data.items.length === 0 ? <div className="card text-muted">Hali buyurtma yo&apos;q</div> :
        data.items.map(o => (
          <Link key={o.id} href={`/order/?id=${o.id}`} className="card flex justify-between gap-2">
            <span>{o.title}<br /><small className="text-muted">{new Date(o.created_at).toLocaleString('ru-RU')}</small></span>
            <span className="text-right"><b>{som(o.price_uzs)}</b><br /><small className="text-muted">{STATUS[o.status] || o.status}</small></span>
          </Link>
        ))}
    </>
  );
}
