'use client';
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { api } from '@/lib/api';
import { useAsync } from '@/lib/hooks';
import { som } from '@/lib/format';
import type { Cat } from '@/lib/types';
import { CatCard, ErrorBox, Loading, TopBar } from '@/components/ui';

type Premium = { plans?: { months: number; price_uzs: number }[] };

function Inner() {
  const sp = useSearchParams();
  const key = sp.get('key') || 'giftcards', title = sp.get('title') || '';
  const { data, error } = useAsync(
    () => (key === 'premium' ? api<Premium>('/premium') : api<{ items: Cat[] }>(`/catalog/${key}`)), [key]);
  return (
    <>
      <TopBar title={title} back />
      {error ? <ErrorBox msg={error} /> : !data ? <Loading /> : key === 'premium' ? (
        <div className="card">
          {((data as Premium).plans || []).map(p => (
            <div key={p.months} className="offer"><span>{p.months} oy</span><b>{som(p.price_uzs)}</b></div>
          ))}
          <small className="text-muted">Sotib olish tez orada qo&apos;shiladi.</small>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {(data as { items: Cat[] }).items.map(c => <CatCard key={c.id} sec={key} c={c} />)}
        </div>
      )}
    </>
  );
}
export default function SectionPage() { return <Suspense fallback={<Loading />}><Inner /></Suspense>; }
