'use client';
import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { api } from '@/lib/api';
import { useAsync } from '@/lib/hooks';
import { som } from '@/lib/format';
import { confirmAsk } from '@/lib/telegram';
import { useStore } from '@/lib/store';
import type { Field, Offer } from '@/lib/types';
import { ErrorBox, Img, Loading, TopBar } from '@/components/ui';

type Detail = { offers?: Offer[]; keys?: Offer[]; fields?: Field[]; region?: string; platform?: string };
const IDK = { topups: 'offer_id', giftcards: 'card_id', gamekeys: 'key_id' } as const;
type Sec = keyof typeof IDK;

function Inner() {
  const sp = useSearchParams(), router = useRouter();
  const sec = (sp.get('sec') || 'topups') as Sec, id = sp.get('id') || '', name = sp.get('name') || '', img = sp.get('img');
  const K = IDK[sec];
  const { refresh, toast } = useStore();
  const { data, error } = useAsync(() => api<Detail>(`/catalog/${sec}/${encodeURIComponent(id)}`), [sec, id]);

  const [sel, setSel] = useState<Offer | null>(null);
  const [qty, setQty] = useState(1);
  const [vals, setVals] = useState<Record<string, string>>({});
  const [code, setCode] = useState('');
  const [applied, setApplied] = useState('');
  const [promo, setPromo] = useState<{ price: number; percent: number } | null>(null);
  const [pmsg, setPmsg] = useState('');
  const [busy, setBusy] = useState(false);

  // re-check promo whenever the selection / quantity changes
  useEffect(() => {
    if (!applied || !sel) { setPromo(null); setPmsg(''); return; }
    let dead = false;
    api<{ price_uzs: number; percent: number }>('/promo/check', 'POST', { section: sec, id, item: sel[K], quantity: qty, code: applied })
      .then(r => { if (!dead) { setPromo({ price: r.price_uzs, percent: r.percent }); setPmsg(`−${r.percent}% qo'llandi ✅`); } })
      .catch(e => { if (!dead) { setPromo(null); setPmsg((e as Error).message); } });
    return () => { dead = true; };
  }, [applied, sel, qty, sec, id, K]);

  if (error) return <><TopBar title={name} back /><ErrorBox msg={error} /></>;
  if (!data) return <><TopBar title={name} back /><Loading /></>;

  const offers = data.offers || data.keys || [], fields = data.fields || [];
  const total = sel ? (promo?.price ?? sel.price_uzs * qty) : 0;
  const pick = (o: Offer) => { setSel(o); setQty(o.min_order_quantity || 1); };
  const step = (d: number) => sel && setQty(Math.min(sel.max_order_quantity || 10, Math.max(sel.min_order_quantity || 1, qty + d)));

  async function buy() {
    if (!sel) return toast('Avval tanlang');
    for (const f of fields) if (!vals[f.key]?.trim()) return toast(`${f.label || f.key} kiriting`);
    if (!(await confirmAsk(`${name} — ${sel.name}${qty > 1 ? ' ×' + qty : ''}\n${som(total)}`))) return;
    setBusy(true);
    try {
      await api('/orders', 'POST', { section: sec, id, item: sel[K], fields: vals, quantity: qty, promo: applied || undefined });
      toast('Buyurtma qabul qilindi ✅'); await refresh(); router.push('/orders/');
    } catch (e) {
      const m = (e as Error).message; toast(m); if (/Balans/.test(m)) router.push('/wallet/');
    } finally { setBusy(false); }
  }

  return (
    <>
      <TopBar title={name} back />
      <div className="card flex items-center gap-3">
        <div className="w-16 shrink-0"><Img src={img} name={name} /></div>
        <div><b>{name}</b><div className="text-sm text-muted">{[data.region, data.platform].filter(Boolean).join(' · ')}</div></div>
      </div>
      {fields.length > 0 && (
        <div className="card">
          <h3 className="mb-2 font-semibold">Ma&apos;lumot</h3>
          {fields.map(f => (
            <input key={f.key} className="inp" placeholder={f.label || f.key} value={vals[f.key] || ''}
              onChange={e => setVals({ ...vals, [f.key]: e.target.value })} />
          ))}
        </div>
      )}
      <div className="card">
        <h3 className="mb-2 font-semibold">Tanlang</h3>
        {offers.length === 0 && <p className="text-sm text-muted">Hozircha mavjud emas</p>}
        {offers.map(o => (
          <button key={o[K] || o.name} disabled={o.stock === 0} onClick={() => pick(o)} className={`offer ${sel === o ? 'offer-on' : ''}`}>
            <span>{o.name}</span>
            <span>{o.old_price_uzs ? <s className="mr-1 text-xs opacity-60">{som(o.old_price_uzs)}</s> : null}<b>{som(o.price_uzs)}</b></span>
          </button>
        ))}
      </div>
      {sec !== 'topups' && (
        <div className="card flex items-center justify-between">
          <b>Miqdor</b>
          <div className="flex items-center gap-3">
            <button className="btn-soft px-4" onClick={() => step(-1)}>−</button><b className="min-w-6 text-center">{qty}</b>
            <button className="btn-soft px-4" onClick={() => step(1)}>+</button>
          </div>
        </div>
      )}
      <div className="card">
        <div className="flex gap-2">
          <input className="inp !mb-0" placeholder="Promo kod" value={code} onChange={e => setCode(e.target.value)} />
          <button className="btn-soft shrink-0" onClick={() => setApplied(code.trim())}>Tekshirish</button>
        </div>
        {pmsg && <small className="text-muted">{pmsg}</small>}
      </div>
      <div className="sticky bottom-20 z-30">
        <button className="btn shadow-pop" disabled={busy || !sel} onClick={buy}>{sel ? `Sotib olish · ${som(total)}` : 'Tanlang'}</button>
      </div>
    </>
  );
}
export default function ProductPage() { return <Suspense fallback={<Loading />}><Inner /></Suspense>; }
