'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { som } from '@/lib/format';
import { openLink } from '@/lib/telegram';
import { useStore } from '@/lib/store';
import { config } from '@/config';
import { ErrorBox, TopBar } from '@/components/ui';

export default function WalletPage() {
  const { me, error, refresh, toast } = useStore();
  const [amount, setAmount] = useState('');
  const [pending, setPending] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { setPending(localStorage.getItem('pp')); }, []);

  // after returning from checkout.uz: poll our server, which re-checks the payment with checkout.uz
  useEffect(() => {
    if (!pending) return;
    let n = 0;
    const t = setInterval(async () => {
      n++;
      try {
        const r = await api<{ status: string }>(`/topup/${pending}`);
        if (r.status === 'paid') { localStorage.removeItem('pp'); setPending(null); await refresh(); toast("To'lov qabul qilindi ✅"); }
      } catch { /* keep polling */ }
      if (n > 75) clearInterval(t);
    }, 4000);
    return () => clearInterval(t);
  }, [pending, refresh, toast]);

  async function pay() {
    setBusy(true);
    try {
      const r = await api<{ payment_id: number; url: string }>('/topup', 'POST', { amount: Number(amount) });
      localStorage.setItem('pp', String(r.payment_id)); setPending(String(r.payment_id)); openLink(r.url);
    } catch (e) { toast((e as Error).message); } finally { setBusy(false); }
  }

  if (error) return <ErrorBox msg={error} />;
  return (
    <>
      <TopBar title="Hamyon" />
      <div className="card">
        <small className="text-muted">Balans</small>
        <div className="my-1 mb-3 text-3xl font-extrabold">{som(me?.user.balance_uzs)}</div>
        <div className="mb-3 flex flex-wrap gap-2">
          {config.topup.chips.map(n => <button key={n} className="chip" onClick={() => setAmount(String(n))}>{n / 1000}k</button>)}
        </div>
        <input className="inp" type="number" inputMode="numeric" placeholder="Summa (1 000 – 10 000 000)" value={amount} onChange={e => setAmount(e.target.value)} />
        <button className="btn" disabled={busy || !amount} onClick={pay}>To&apos;ldirish</button>
        <p className="mt-2 text-sm text-muted">Click, Payme, Uzcard/Humo, Plum orqali.</p>
        {pending && <p className="mt-1 text-sm text-accent">To&apos;lov kutilmoqda…</p>}
      </div>
    </>
  );
}
