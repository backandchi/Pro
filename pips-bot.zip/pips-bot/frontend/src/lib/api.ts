import { initData } from './telegram';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function api<T = any>(path: string, method = 'GET', body?: unknown): Promise<T> {
  const r = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Init-Data': initData() },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j as { error?: string }).error || `Xatolik ${r.status}`);
  return j as T;
}
