export type Cat = { id: string; name: string; image?: string | null; note?: string | null };
export type Offer = {
  offer_id?: string; card_id?: string; key_id?: string; name: string;
  price_uzs: number; old_price_uzs?: number; stock?: number; min_order_quantity?: number; max_order_quantity?: number;
};
export type Field = { key: string; label?: string; type?: string };
export type Me = { user: { tg_id: number | string; name: string; balance_uzs: number | string }; is_admin: boolean };
export type Banner = { id: number; title: string; image_url: string; link?: string | null };
export type Home = { banners: Banner[]; topups: Cat[]; sections: { key: string; title: string }[] };
export type OrderRow = { id: number; title: string; price_uzs: number | string; status: string; created_at: string };
