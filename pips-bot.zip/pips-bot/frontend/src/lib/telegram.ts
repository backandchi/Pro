/* eslint-disable @typescript-eslint/no-explicit-any */
export const tg = (): any => (typeof window !== 'undefined' ? (window as any).Telegram?.WebApp : undefined);
export const initData = (): string => tg()?.initData || process.env.NEXT_PUBLIC_DEV_INIT_DATA || '';
export const openLink = (url: string) => { if (!/^https?:/.test(url)) return; const w = tg(); w?.openLink ? w.openLink(url) : window.open(url, '_blank'); };
export const confirmAsk = (msg: string) =>
  new Promise<boolean>(res => { const w = tg(); w?.showConfirm ? w.showConfirm(msg, (ok: boolean) => res(ok)) : res(window.confirm(msg)); });
