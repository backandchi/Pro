'use client';
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api } from './api';
import { tg } from './telegram';
import type { Me } from './types';

type Ctx = { me: Me | null; error: string; refresh: () => Promise<void>; toast: (t: string) => void; theme: string; toggleTheme: () => void };
const C = createContext<Ctx>(null as unknown as Ctx);
export const useStore = () => useContext(C);

/** One provider: current user/balance, theme (light/dark via data-theme), toasts. */
export function StoreProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState('');
  const [theme, setTheme] = useState('light');

  const refresh = useCallback(async () => {
    try { setMe(await api<Me>('/me')); setError(''); } catch (e) { setError((e as Error).message); }
  }, []);

  useEffect(() => {
    const w = tg(); w?.ready(); w?.expand();
    const t = localStorage.getItem('theme') || w?.colorScheme || 'light';
    setTheme(t); document.documentElement.dataset.theme = t;
    refresh();
  }, [refresh]);

  const toggleTheme = () => {
    const t = theme === 'dark' ? 'light' : 'dark';
    setTheme(t); localStorage.setItem('theme', t); document.documentElement.dataset.theme = t;
  };
  const toast = useCallback((t: string) => { setMsg(t); setTimeout(() => setMsg(''), 2800); }, []);

  return (
    <C.Provider value={{ me, error, refresh, toast, theme, toggleTheme }}>
      {children}
      {msg && <div className="fixed left-1/2 top-4 z-50 max-w-[90%] -translate-x-1/2 rounded-md bg-text px-4 py-2.5 text-center text-bg shadow-pop">{msg}</div>}
    </C.Provider>
  );
}
