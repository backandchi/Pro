export const som = (n: number | string | undefined | null) =>
  Number(n || 0).toLocaleString('ru-RU').replace(/\u00a0/g, ' ') + " so'm";

export const STATUS: Record<string, string> = {
  pending: 'Jarayonda', processing: 'Jarayonda', created: 'Jarayonda',
  completed: 'Bajarildi ✅', failed: 'Bekor, pul qaytarildi', review: 'Tekshiruvda',
};

/** Pretty-print the delivery payload (codes/keys) as indented key: value lines. */
export const kv = (o: unknown, d = 0): string =>
  Array.isArray(o) ? o.map(x => kv(x, d)).join('\n')
  : o && typeof o === 'object'
    ? Object.entries(o as Record<string, unknown>)
        .map(([k, v]) => (v && typeof v === 'object' ? `${' '.repeat(d)}${k}:\n${kv(v, d + 2)}` : `${' '.repeat(d)}${k}: ${v}`)).join('\n')
    : `${' '.repeat(d)}${o}`;
