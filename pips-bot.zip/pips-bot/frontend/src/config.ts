/** Single place to re-skin the app (same idea as Nova's src/config.ts). */
export const config = {
  brand: { name: 'pips bot' },
  topup: { min: 1000, max: 10_000_000, chips: [10_000, 20_000, 50_000, 100_000] },
} as const;
