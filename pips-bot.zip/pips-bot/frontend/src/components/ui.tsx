'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import type { ReactNode } from 'react';
import { useStore } from '@/lib/store';
import { som } from '@/lib/format';
import type { Cat } from '@/lib/types';

export const Loading = () => <div className="card text-muted">Yuklanmoqda…</div>;
export const ErrorBox = ({ msg }: { msg: string }) => <div className="card text-danger">⚠️ {msg}</div>;

export function Img({ src, name, className = '' }: { src?: string | null; name: string; className?: string }) {
  return src
    // eslint-disable-next-line @next/next/no-img-element
    ? <img src={src} alt="" loading="lazy" className={`aspect-square w-full rounded-md bg-surface object-cover ${className}`} onError={e => { e.currentTarget.style.visibility = 'hidden'; }} />
    : <div className={`grid aspect-square w-full place-items-center rounded-md bg-accent-soft text-2xl font-bold text-accent ${className}`}>{(name || '?')[0]}</div>;
}

export function BalanceChip() {
  const { me } = useStore();
  return <Link href="/wallet/" className="chip">💰 {som(me?.user.balance_uzs)}</Link>;
}

export function TopBar({ title, back, right }: { title: string; back?: boolean; right?: ReactNode }) {
  const router = useRouter();
  const { theme, toggleTheme } = useStore();
  return (
    <div className="mb-3 flex items-center justify-between gap-2">
      <div className="flex min-w-0 items-center gap-2">
        {back && <button aria-label="Orqaga" className="px-1 text-3xl leading-none text-accent" onClick={() => router.back()}>‹</button>}
        <b className="truncate text-xl">{title}</b>
      </div>
      <div className="flex items-center gap-2">
        {right}
        <button aria-label="Mavzu" className="text-xl" onClick={toggleTheme}>{theme === 'dark' ? '☀️' : '🌙'}</button>
      </div>
    </div>
  );
}

/** Grid card for a game / gift-card category / game key. */
export function CatCard({ sec, c }: { sec: string; c: Cat }) {
  const q = new URLSearchParams({ sec, id: c.id, name: c.name, img: c.image || '' });
  return (
    <Link href={`/product/?${q}`} className="flex flex-col items-center gap-1.5 rounded-lg border border-border bg-card p-2 text-center text-xs shadow-card">
      <Img src={c.image} name={c.name} />
      <span className="line-clamp-2">{c.name}</span>
    </Link>
  );
}

export function BottomNav() {
  const path = usePathname() || '/';
  const { me } = useStore();
  const items: [string, string, string][] = [['/', '🏠', 'Bosh'], ['/wallet/', '💰', 'Hamyon'], ['/orders/', '📦', 'Buyurtmalar']];
  if (me?.is_admin) items.push(['/admin/', '⚙️', 'Admin']);
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-panel/95 backdrop-blur">
      <div className="mx-auto flex max-w-app" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {items.map(([href, icon, label]) => {
          const on = href === '/' ? path === '/' : path.startsWith(href);
          return (
            <Link key={href} href={href} className={`flex-1 py-2 text-center text-xs ${on ? 'font-semibold text-accent' : 'text-muted'}`}>
              <div className="text-lg">{icon}</div>{label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
