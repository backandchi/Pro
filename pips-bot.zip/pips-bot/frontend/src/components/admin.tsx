'use client';
import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { api } from '@/lib/api';

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
type FieldDef = 'text' | 'number' | 'datetime-local' | string[];

export function Table({ rows, actions }: { rows: Row[]; actions?: (r: Row) => ReactNode }) {
  if (!rows.length) return <p className="text-sm text-muted">Bo&apos;sh</p>;
  const keys = Object.keys(rows[0]).filter(k => !k.startsWith('__'));
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead><tr>{keys.map(k => <th key={k} className="px-2 py-1 text-left font-medium text-muted">{k}</th>)}{actions && <th />}</tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-t border-border">
              {keys.map(k => <td key={k} className="max-w-[200px] truncate whitespace-nowrap px-2 py-1.5">{String(r[k] ?? '')}</td>)}
              {actions && <td className="whitespace-nowrap px-2">{actions(r)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---- Providers: Fazer / checkout.uz keys, FX rate, default markup (all stored in DB, no .env) ----
const FIELDS: [string, string][] = [
  ['fazer_api_key', 'Fazer Cards API key'], ['fazer_webhook_secret', 'Fazer webhook secret'], ['checkout_api_key', 'checkout.uz API key'],
  ['usd_uzs_rate', "Kurs (1 USD = ? so'm)"], ['markup_percent', 'Umumiy ustama %'], ['public_url', 'Sayt manzili (https://pips.uz)'],
];
export function Providers() {
  const [cur, setCur] = useState<Record<string, string>>({});
  const [form, setForm] = useState<Record<string, string>>({});
  const [out, setOut] = useState('');
  const load = useCallback(() => api<{ settings: Record<string, string> }>('/admin/settings').then(r => setCur(r.settings)).catch(e => setOut((e as Error).message)), []);
  useEffect(() => { load(); }, [load]);
  const save = async () => {
    try {
      const r = await api<{ checkout_webhook_url: string }>('/admin/settings', 'PUT', form);
      setOut('Saqlandi. checkout.uz webhook URL: ' + r.checkout_webhook_url); setForm({}); load();
    } catch (e) { setOut((e as Error).message); }
  };
  const test = async () => { try { setOut(JSON.stringify(await api('/admin/providers'))); } catch (e) { setOut((e as Error).message); } };
  return (
    <div className="card">
      {FIELDS.map(([k, l]) => (
        <input key={k} className="inp" placeholder={`${l}${cur[k] ? ' — hozir: ' + cur[k] : ''}`} value={form[k] ?? ''} onChange={e => setForm({ ...form, [k]: e.target.value })} />
      ))}
      <div className="flex gap-2"><button className="btn" onClick={save}>Saqlash</button><button className="btn-soft shrink-0" onClick={test}>Tekshirish</button></div>
      <p className="mt-2 break-all text-sm text-muted">{out}</p>
    </div>
  );
}

// ---- Products: auto-imported Fazer cards; hide / re-import ----
export function Products() {
  const [kind, setKind] = useState('topups');
  const [rows, setRows] = useState<Row[]>([]);
  const [msg, setMsg] = useState('');
  const load = useCallback(() => api<{ items: Row[] }>('/admin/products?kind=' + kind).then(r => setRows(r.items)).catch(e => setMsg((e as Error).message)), [kind]);
  useEffect(() => { load(); }, [load]);
  const sync = async () => { setMsg('Import…'); try { const r = await api<{ count: number }>('/admin/sync', 'POST'); setMsg(`${r.count} ta karta import qilindi`); load(); } catch (e) { setMsg((e as Error).message); } };
  const toggle = async (p: Row) => { await api(`/admin/products/${kind}/${encodeURIComponent(p.category_id)}`, 'PATCH', { hidden: !p.hidden }); load(); };
  return (
    <div className="card">
      <div className="mb-2 flex gap-2">
        <select className="inp !mb-0" value={kind} onChange={e => setKind(e.target.value)}>{['topups', 'giftcards', 'gamekeys'].map(k => <option key={k}>{k}</option>)}</select>
        <button className="btn-soft shrink-0" onClick={sync}>Fazer&apos;dan import</button>
      </div>
      <p className="mb-2 text-sm text-muted">{msg}</p>
      <Table rows={rows.map(p => ({ id: p.category_id, name: p.custom_name || p.name, hidden: p.hidden, gone: p.gone, sort: p.sort, __p: p }))} actions={r => <button className="btn-soft" onClick={() => toggle(r.__p)}>{r.hidden ? "Ko'rsat" : 'Yashir'}</button>} />
    </div>
  );
}

// ---- Generic CRUD: folders, discounts, promos, banners (reklama), markups ----
export const RES: Record<string, { title: string; f: Record<string, FieldDef>; toggle?: string; key?: string }> = {
  folders: { title: 'Papkalar', f: { name: 'text', kind: ['discount', 'promo'] } },
  discounts: { title: 'Chegirmalar', f: { name: 'text', folder_id: 'number', percent: 'number', category_id: 'text', starts_at: 'datetime-local', ends_at: 'datetime-local' }, toggle: 'active' },
  promos: { title: 'Promo kodlar', f: { code: 'text', folder_id: 'number', percent: 'number', max_uses: 'number', min_amount_uzs: 'number', expires_at: 'datetime-local' }, toggle: 'active' },
  banners: { title: 'Reklama', f: { title: 'text', image_url: 'text', link: 'text', sort: 'number', starts_at: 'datetime-local', ends_at: 'datetime-local' }, toggle: 'active' },
  markups: { title: 'Ustama', f: { category_id: 'text', percent: 'number' }, key: 'category_id' },
};
export function Resource({ t }: { t: string }) {
  const R = RES[t], keyF = R.key || 'id';
  const [rows, setRows] = useState<Row[]>([]);
  const [form, setForm] = useState<Record<string, string>>({});
  const [err, setErr] = useState('');
  const load = useCallback(() => api<{ items: Row[] }>('/admin/' + t).then(r => setRows(r.items)).catch(e => setErr((e as Error).message)), [t]);
  useEffect(() => { setForm({}); setErr(''); load(); }, [load]);
  const add = async () => {
    const b: Record<string, string> = {};
    for (const k of Object.keys(R.f)) if (form[k]) b[k] = form[k];
    try {
      if (R.key) await api(`/admin/${t}/${encodeURIComponent(b[R.key] || '')}`, 'PUT', b); else await api('/admin/' + t, 'POST', b);
      setForm({}); setErr(''); load();
    } catch (e) { setErr((e as Error).message); }
  };
  const call = async (r: Row, method: 'PATCH' | 'DELETE') => {
    const url = `/admin/${t}/${encodeURIComponent(r[keyF])}`;
    if (method === 'DELETE') await api(url, 'DELETE'); else await api(url, 'PATCH', { [R.toggle as string]: !r[R.toggle as string] });
    load();
  };
  return (
    <div className="card">
      <div className="mb-2 grid grid-cols-2 gap-2">
        {Object.entries(R.f).map(([k, def]) => Array.isArray(def)
          ? <select key={k} className="inp !mb-0" value={form[k] || ''} onChange={e => setForm({ ...form, [k]: e.target.value })}><option value="">{k}…</option>{def.map(o => <option key={o}>{o}</option>)}</select>
          : <input key={k} className="inp !mb-0" type={def} placeholder={k} value={form[k] || ''} onChange={e => setForm({ ...form, [k]: e.target.value })} />)}
      </div>
      <button className="btn mb-2" onClick={add}>Qo&apos;shish</button>
      {err && <p className="mb-2 text-sm text-danger">{err}</p>}
      <Table rows={rows} actions={r => (
        <>
          {R.toggle && <button className="btn-soft mr-1" onClick={() => call(r, 'PATCH')}>{r[R.toggle] ? "O'chir" : 'Yoq'}</button>}
          <button className="btn-soft" onClick={() => call(r, 'DELETE')}>✕</button>
        </>
      )} />
    </div>
  );
}

export function Plain({ t }: { t: 'orders' | 'payments' }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [err, setErr] = useState('');
  useEffect(() => { api<{ items: Row[] }>('/admin/' + t).then(r => setRows(r.items)).catch(e => setErr((e as Error).message)); }, [t]);
  return <div className="card">{err ? <p className="text-danger">{err}</p> : <Table rows={rows} />}</div>;
}
