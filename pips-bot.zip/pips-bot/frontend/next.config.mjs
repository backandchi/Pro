const prod = process.env.NODE_ENV === 'production';

/** Production = static export (served by the Express backend from /public).
 *  Dev = proxy /api to the backend so `npm run dev` works against a local server. */
/** @type {import('next').NextConfig} */
const config = {
  images: { unoptimized: true },
  trailingSlash: true,
  ...(prod
    ? { output: 'export' }
    : {
        skipTrailingSlashRedirect: true,
        async rewrites() {
          return [{ source: '/api/:path*', destination: `${process.env.API_URL || 'http://localhost:3000'}/api/:path*` }];
        },
      }),
};
export default config;
